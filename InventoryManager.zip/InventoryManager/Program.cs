using System;
using System.Windows.Forms;
using InventoryManagementSystem;
using InventoryManager;  

namespace InventoryManager
{
    internal static class Program
    {
       
        [STAThread]
        static void Main()
        {
            
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());  
        }
    }
}
