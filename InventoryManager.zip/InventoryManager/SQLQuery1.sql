﻿CREATE TABLE Products (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100),
    Category NVARCHAR(100),
    Quantity INT,
    Price DECIMAL(18, 2)
);
